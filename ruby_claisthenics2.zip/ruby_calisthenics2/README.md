Ruby Calisthenics
=================

The goal of this multi-part assignment is to get you more practice with basic
Ruby coding